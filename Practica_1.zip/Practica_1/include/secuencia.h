#ifndef SECUENCIA_H
#define SECUENCIA_H

class SecuenciaCaracteres{
private:
    /**
     * Constante para el TAMANIO maximo de las secuencias
     */
    static const int TAMANIO = 5000;
    
    /**
     * secuencia de caracteres
     */
    char v[TAMANIO];
    
    /**
     * Contador de posiciones usadas
     */
    int utilizados;
    
    /**
     * Devuelve el contador de ocurrencias de un determinado
     * caracter
     * @param caracter caracter objetivo
     * @return contador de ocurrencias
     */
    
    int contarOcurrencias(char caracter);
    
public:
    
    /**
     * Constructor por defecto
     * Metodo ya implementado
     * @return 
     */
    SecuenciaCaracteres();

    /**
     * Devuelve el numero de posiciones usadas
     * Metodo ya implementado
     * @return 
     */
    int obtenerUtilizados();
    
    /**
     * Devuelve el espacio total en la secuencia
     * Metodo ya implementado
     * @return 
     */
    int capacidad();
    
    /**
     * Agrega un nuevo caracter a la secuencia
     * Metodo ya implementado
     * @param nuevo
     */
    void aniade(char nuevo);
   
    /**
     * Se accede al caracter de una posicion. 
     * Metodo ya implementado
     * NOTA: no se comprueba la validez del indice
     * @param indice indice objetivo
     * @return caracter almacenado en indice
     */
    char elemento(int indice);
    
    /**
     * Localiza la primera ocurrencia del caracter
     * pasado como argumento
     * Metodo ya implementado
     * @param aBuscar caracter a buscar
     * @return posicion de primera ocurrencia del caracter
     */
    int primeraOcurrencia(char aBuscar);
   
    /**
     * Construye la subsecuencia contenida entre dos posiciones
     * @param posIni
     * @param posFin
     * @return 
     */
    SecuenciaCaracteres subsecuencia(int posIni, int posFin);
    
    bool esPalisimetrica();
};

/**
 * muestra una secuencia de caracteres en la salidad estandar
 * @param s secuencia a mostrar
 */
void pintaSecuencia(SecuenciaCaracteres s);

#endif /* SECUENCIA_H */