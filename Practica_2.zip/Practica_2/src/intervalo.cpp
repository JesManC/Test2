#include <iostream>
#include "intervalo.h"

using namespace std;
        
/**
 * @brief comprueba que los argumentos definen un intervalo correcto
 * @param cotaInferior
 * @param cotaSuperior
 * @param cerradoInferior
 * @param cerradoSuperior
 * @pre cotaInferior < cotaSuperior 
 * @pre cotaInferior == cotaSuperior && cerradoInferior == cerradoSuperior 
 * @return @retval true si correcto @retval false en otro caso
 */
bool Intervalo::validar(double cotaInferior, double cotaSuperior, bool cerradoInferior, bool cerradoSuperior);

/** 
 *  @brief Crea un intervalo vacio 
 */
Intervalo::Intervalo();
/** 
 * @brief Crea un Intervalo cerrado 
 * @param cotaInferior
 * @param cotaSuperior
 * @pre El intervalo es válido
 */
Intervalo::Intervalo(double cotaInferior, double cotaSuperior);
/** 
 * @brief Crea un intervalo cualquiera 
 * @param cotaInferior
 * @param cotaSuperior
 * @param cerradoInferior
 * @param cerradoSuperior
 * @pre El intervalo es válido
 */
Intervalo::Intervalo(double cotaInferior, double cotaSuperior, bool cerradoInferior, bool cerradoSuperior);
/** 
 * @brief Devuelve la cota inferior del intervalo
 * @return El valor de la cota
 */
double Intervalo::getCotaInf()const ;
/** 
 * @brief Devuelve la cota superior del intervalo
 * @return El valor de la cota
 */
double Intervalo::getCotaSup()const ;
/** 
 * @brief Consulta si el intervalo es cerrado en su cota inferior
 * @return @retval true si es cerrado @retval false si es cerrado
 */
bool Intervalo::esCerradoInf()const ;
/** 
 * @brief Consulta si el intervalo es cerrado en su cota superior
 * @return @retval true si es cerrado @retval false si es cerrado
 */
bool Intervalo::esCerradoSup()const ;
/** 
 * @brief Consulta si el intervalo almacenado es vacío o no
 * @return @retval true si es un intervalo vacío, @retval false en otro caso 
 */
bool Intervalo::esVacio()const ;
/** 
 * @brief Consulta si un determinado valor está dentro del intervalo
 * @param n El valor consultado
 * @return @retval true si el valor @p n pertenece al intervalo, @retval false en otro caso 
 */
bool Intervalo::estaDentro(double n)const ;


/** 
* @brief Imprime los valores de un intervalo de forma visual según lo indicado en el guión
* @param i El intervalo
*/
void escribir(const Intervalo &i){}

/** 
* @brief Lee los valores del intervalo según el formato indicado en el guión
* @param i El intervalo
*/
void leer(Intervalo &i){}

Intervalo::Intervalo(double cinf,double csup){
    assert (validar(cinf,csup, true, true));
    cotaInf = cinf;
    cotaSup = csup;
    cerradoInf = true;
    cerradoSup = true;
}